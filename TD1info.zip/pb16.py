def pb16(n):
    l=str(2**n)
    s=0
    m=len(l)
    for k in range(m):
       s=s+int(l[k])
    return(s)

print('la somme des des chiffres composants 2**1000 est :')
print(pb16(1000))
