def pb22():
    fichier = open('p022_names.txt', 'r')
    for ligne in fichier:
        Dossier=ligne.split(',')   
    TRI=sorted(Dossier)
    n=len(TRI)
    somme=0
    for k in range(n):
        nom=TRI[k]
        somme+=(k+1)*correspondance(nom)
    return(somme)
        
def correspondance(nom):
    chaine='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    sprime=0
    n=len(nom)
    for j in range(1,n-1):
        sprime+=1+chaine.index(nom[j])    
    return(sprime)


print("le score total du fichier p022_names est:")
print(pb22())