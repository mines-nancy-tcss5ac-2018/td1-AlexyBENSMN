def estpalindrome(k):
    chaine=str(k)
    j=0
    n=len(chaine)
    while (j<n-j and chaine[j]==chaine[n-j-1]):
        j=j+1
    return(j>=n-j)

def mirroir(l):
    n=len(l)
    for k in range(n):
        l[k],l[n-k-1]=l[n-k-1],l[k]

def estlychrel(n):
    compteur=1
    s=0
    chaine=str(n)
    m=len(chaine)
    for k in range(m):
       s=s+int(chaine[k])*10**k+int(chaine[m-k-1])*10**k
    while compteur<50 and not estpalindrome(s):
        compteur=compteur+1
        chaine=str(s)
        m=len(chaine)
        s=0
        for k in range(m):
            s=s+int(chaine[k])*10**k+int(chaine[m-k-1])*10**k
    return(compteur==50)
    
def pb55(n):
    compteur=0
    for k in range(n+1):
        if estlychrel(k):
            compteur=compteur+1
    return(compteur)

print('Le nombre de nombre de lychrel en dessous de 10000 est')
print(pb55(10000))